using System;

public interface IMensagem
{
    string Conteudo { get; set; }
    DateTime DataEnvio { get; }
    void Enviar();
}

// Classes para tipos específicos de mensagens
public class MensagemTexto : IMensagem
{
    public string Conteudo { get; set; }
    public DateTime DataEnvio { get; } = DateTime.Now;

    public void Enviar()
    {
        Console.WriteLine($"Enviando mensagem de texto: '{Conteudo}'");
    }
}

public abstract class MensagemMidia : IMensagem
{
    public string Conteudo { get; set; }
    public DateTime DataEnvio { get; } = DateTime.Now;
    public string Arquivo { get; set; }

    public abstract void Enviar();
}

public class MensagemVideo : MensagemMidia
{
    public string Formato { get; set; }
    public TimeSpan Duracao { get; set; }

    public override void Enviar()
    {
        Console.WriteLine($"Enviando vídeo: '{Conteudo}' ({Formato}, {Duracao})");
    }
}

public class MensagemFoto : MensagemMidia
{
    public string Formato { get; set; }

    public override void Enviar()
    {
        Console.WriteLine($"Enviando foto: '{Conteudo}' ({Formato})");
    }
}

public class MensagemArquivo : MensagemMidia
{
    public string Formato { get; set; }

    public override void Enviar()
    {
        Console.WriteLine($"Enviando arquivo: '{Conteudo}' ({Formato})");
    }
}

// Interface 
public interface ICanalComunicacao
{
    void EnviarMensagem(IMensagem mensagem);
}

// Classes 
public class CanalWhatsApp : ICanalComunicacao
{
    public string NumeroTelefone { get; set; }

    public void EnviarMensagem(IMensagem mensagem)
    {
        Console.WriteLine($"Enviando mensagem para WhatsApp ({NumeroTelefone}):");
        mensagem.Enviar();
    }
}

public class CanalTelegram : ICanalComunicacao
{
    public string Usuario { get; set; }

    public void EnviarMensagem(IMensagem mensagem)
    {
        Console.WriteLine($"Enviando mensagem para Telegram ({Usuario}):");
        mensagem.Enviar();
    }
}

public class CanalFacebook : ICanalComunicacao
{
    public string Usuario { get; set; }

    public void EnviarMensagem(IMensagem mensagem)
    {
        Console.WriteLine($"Enviando mensagem para Facebook ({Usuario}):");
        mensagem.Enviar();
    }
}

public class CanalInstagram : ICanalComunicacao
{
    public string Usuario { get; set; }

    public void EnviarMensagem(IMensagem mensagem)
    {
        Console.WriteLine($"Enviando mensagem para Instagram ({Usuario}):");
        mensagem.Enviar();
    }
}

class Program
{
    static void Main()
    {
      
        ICanalComunicacao canalWhatsApp = new CanalWhatsApp { NumeroTelefone = " O de numero 992345678  Está inativo, como posso ajudar?" };
        ICanalComunicacao canalTelegram = new CanalTelegram { Usuario = " @Claudio_823  Está inativo, como posso ajudar?" };
        ICanalComunicacao canalFacebook = new CanalFacebook { Usuario = "Claudio paiva Está inativo, como posso ajudar?" };
        ICanalComunicacao canalInstagram = new CanalInstagram { Usuario = "Claudio.paiva99 Está inativo, como posso ajudar?" };

        canalWhatsApp.EnviarMensagem(new MensagemTexto { Conteudo = "Bom dia, me chamo claudio,como posso te ajudar" });
        canalTelegram.EnviarMensagem(new MensagemVideo { Conteudo = "Apresentação", Arquivo = "video.mp4", Formato = "MP4", Duracao = TimeSpan.FromMinutes(2) });
        canalFacebook.EnviarMensagem(new MensagemFoto { Conteudo = "Paisagem", Arquivo = "foto.jpg", Formato = "JPEG" });
        canalInstagram.EnviarMensagem(new MensagemArquivo { Conteudo = "Documento", Arquivo = "documento.pdf", Formato = "PDF" });
    }
}
